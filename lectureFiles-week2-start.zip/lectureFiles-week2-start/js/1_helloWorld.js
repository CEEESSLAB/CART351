

document.write("<h2>Welcome to WEEK TWO CART 351 TWO</h2>");
window.onload = function () {

    console.log("hello world in the console");
    //document.write("<p>Welcome to WEEK TWO CART 351</p>");

    // this is a single
    /*jdnfdnfkdnf
    */

}

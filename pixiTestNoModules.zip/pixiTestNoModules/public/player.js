class Player{
    constructor(x,y,image,clientSocket){

         //This code will run when the loader has finished loading the image
    this.psprite  = new PIXI.Sprite(
        PIXI.Loader.shared.resources[image].texture
    
      );
  
       //Change the sprite's position
       this.psprite.x = x;
       this.psprite.y = y;
  
       this.psprite.scale.x = 1.5;
       this.psprite.scale.y = 1.5;
    
  
       this.psprite.vx = 5;
       this.psprite.vy = 5;

       this.clientSocket = clientSocket;
    

    }

    updateKeys(keyCode){

        console.log("in here");
       //console.log(keyCode);
        if (keyCode == 87) {
            this.psprite.y -=  this.psprite.vy;
        } else if (keyCode == 83) {
            this.psprite.y +=  this.psprite.vy;
        } else if (keyCode == 65) {
            this.psprite.x -=  this.psprite.vx;
        } else if (keyCode == 68) {
            this.psprite.x +=  this.psprite.vx;
        } 
        //send the NEW position through web socket ;)
        this.clientSocket.emit("playerMoved",{x:this.psprite.x, y:this.psprite.y});
        
    }

// updateWithKeys(){


// keyObjectW.press = () => {

   
//     //key object pressed
//     this.psprite.y -=  this.psprite.vy;

//   };
//   keyObjectW.release = () => {
//     //key object released
   
//   };

//   keyObjectA.press = () => {
//     this.psprite.x -=  this.psprite.vx;
   
//     //key object pressed
//   };
//   keyObjectA.release = () => {
//     //key object released
   
   
//   };
//   keyObjectS.press = () => {
//     this.psprite.x +=  this.psprite.vx;
 
//     //key object pressed
//   };
//   keyObjectS.release = () => {
//     //key object released
    
//   };
//   keyObjectD.press = () => {

//     //key object pressed
//     this.psprite.y +=  this.psprite.vy;
//   };
//   keyObjectD.release = () => {
//     //key object released
  
//   };

//     }

    update(){

        this.psprite.x +=  this.psprite.vx;
    }
}
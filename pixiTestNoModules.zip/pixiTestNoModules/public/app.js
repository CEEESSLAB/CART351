//Create a Pixi Application
// const app = new PIXI.Application({width: 256, height: 256});
const app = new PIXI.Application({
  width: 256, // default: 800
  height: 256, // default: 600
  antialias: true, // default: false
  transparent: false, // default: false
  resolution: 1, // default: 1
});



let io_socket = io();
let clientSocket = io_socket.connect("http://localhost:4200");
let socketId = -1;

let currentPlayer;
let otherPlayer;

//change background
app.renderer.backgroundColor = 0x061639;

//auto full window
app.renderer.view.style.position = "absolute";
app.renderer.view.style.display = "block";
app.renderer.autoDensity = true;
app.resizeTo = window;

//Add the canvas that Pixi automatically created for you to the HTML document
document.body.appendChild(app.view);

  clientSocket.on("connect", function (data) {
    console.log("connected");
    // put code here that should only execute once the client is connected
    clientSocket.emit("join", "msg:: client joined");
    // handler for receiving client id
    clientSocket.on("joinedClientId", function (data) {
      
      socketId = data.id;

      PIXI.Loader.shared.add("images/p1_s.png").add("images/p2_s.png").load(setup);

      function setup(){
      //make new
      playerOne = new Player(10, 96, "images/p1_s.png",clientSocket);
      playerTwo = new Player(180, 50, "images/p2_s.png",clientSocket);

      //set
      currentPlayer = eval(data.playerChoice);
      otherPlayer = eval(data.playerOther);

      console.log("myId " + socketId);


      app.stage.addChild(currentPlayer.psprite);
      app.stage.addChild(otherPlayer.psprite);
      app.renderer.render(app.stage);
      
      // ADD::
      runOnceConnected();
      }
    });
  });


function runOnceConnected() {


    clientSocket.on("updatePlayerFromServer", function (otherPosition) {
        console.log(otherPosition);
        otherPlayer.psprite.x =otherPosition.x;
        otherPlayer.psprite.y =otherPosition.y;

      });

      app.ticker.add((delta) => gameLoop(delta));
  
}

function gameLoop(delta) {
  // player.update();
}

document.addEventListener("keydown", onDocumentKeyDown, false);

function onDocumentKeyDown(event) {
  let keyCode = event.which;
  // console.log(keyCode);
  if(currentPlayer!==undefined){
    console.log(currentPlayer)
    currentPlayer.updateKeys(keyCode);

  }

}

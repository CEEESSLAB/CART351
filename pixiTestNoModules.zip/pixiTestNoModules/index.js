//import the Express library
let express = require("express");
const portNumber = 4200;
let app = express(); //make an instance of express
let httpServer = require("http").createServer(app); // create a server (using the Express framework object)
// declare io which mounts to our httpServer object (runs on top ... )
let io = require("socket.io")(httpServer);
let clientIncrementing = 0;

// serving static files
let static = require("node-static"); // for serving static files (i.e. css,js,html...)
// serve anything from this dir ...
app.use(express.static(__dirname + "/public"));
// for the client...
app.use(express.static(__dirname + "/node_modules"));

//default route
app.get("/", function (req, res) {
  res.send("<h1>Hello world</h1>");
});

app.get("/client", function (req, res) {
  res.sendFile(__dirname + "/public/index.html");
});

httpServer.listen(portNumber, function () {
  console.log("listening on port:: " + portNumber);
});

io.on("connect", function (socket) {
  console.log("original id:: " + socket.id);

  socket.on("join", function (data) {
    //received a join msg

    // send back the id
    if (clientIncrementing % 2 == 0) {
      socket.emit("joinedClientId", {
        id: socket.id,
        playerChoice: "playerOne",
        playerOther: "playerTwo",
      });
    } else {
      socket.emit("joinedClientId", {
        id: socket.id,
        playerChoice: "playerTwo",
        playerOther: "playerOne",
      });
    }
    clientIncrementing++;
    console.log("a new user with id " + socket.id + " has entered");
  });

  socket.on("playerMoved", function (data) {
    //broadcast to all others
    socket.broadcast.emit("updatePlayerFromServer", data);
  });
});
